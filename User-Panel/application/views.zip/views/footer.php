<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


            </div>
            <!-- content-wrapper ends -->
            <!-- partial:partials/_footer.html -->
<!--            <footer class="footer">-->
<!---->
<!--            </footer>-->
        <!-- partial -->
        </div>
    <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
</div>

<!-- plugins:js -->
<script src="<?=base_url()?>template/vendors/js/vendor.bundle.base.js"></script>
<script src="<?=base_url()?>template/vendors/js/vendor.bundle.addons.js"></script>
<!-- endinject -->
<!-- Plugin js for this page-->
<!-- End plugin js for this page-->
<!-- inject:js -->
<script src="<?=base_url()?>template/js/off-canvas.js"></script>
<script src="<?=base_url()?>template/js/hoverable-collapse.js"></script>
<script src="<?=base_url()?>template/js/template.js"></script>
<script src="<?=base_url()?>template/js/settings.js"></script>
<script src="<?=base_url()?>template/js/todolist.js"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="<?=base_url()?>template/js/dashboard.js"></script>
<script src="<?=base_url()?>template/js/tooltips.js"></script>
<script src="<?=base_url()?>template/js/popover.js"></script>
<!-- End custom js for this page-->
<script src="<?=base_url()?>template/js/popover.js"></script>
<script src="<?=base_url()?>template/js/data-table.js"></script>
</body>

</html>