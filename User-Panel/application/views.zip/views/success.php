<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

/////////////////// the buy form file //////////////////
<div class="container">


    <div class="starter-template">
        <h1>PayPal Payment</h1>
        <p class="lead">Success</p>
    </div>

    <div class="contact-form">
        <div>
            <h2 style="font-family: 'quicksandbold'; font-size:16px; color:#313131; padding-bottom:8px;">Dear Member</h2>
            <span style="color: #646464;">Your payment was successful, thank you for purchase.</span><br/>
        </div>
    </div>
</div><!-- /.container -->